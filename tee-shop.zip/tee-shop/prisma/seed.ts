import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'
const db = new PrismaClient()

async function main() {
  const email = (process.env.SEED_OWNER_EMAIL ?? 'owner@example.com').toLowerCase()
  await db.user.upsert({
    where: { email }, update: {},
    create: { email, name: 'Owner', role: 'OWNER',
      passwordHash: await bcrypt.hash(process.env.SEED_OWNER_PASSWORD ?? 'change-me-now', 12) },
  })
  await db.product.upsert({
    where: { slug: 'classic-heavyweight-tee' }, update: {},
    create: {
      slug: 'classic-heavyweight-tee', name: 'Classic Heavyweight Tee',
      description: '240gsm combed cotton. Boxy fit, double-stitched hem, prints that survive the wash.',
      priceCents: 2800,
      variants: { create: ['S', 'M', 'L', 'XL'].map((size) => ({ size, color: 'Black', stock: 25 })) },
    },
  })
  console.log('Seeded. Log in at /admin/login with', email)
}
main().finally(() => db.$disconnect())
