'use client'
import { useState } from 'react'
import { saveProduct } from '@/app/admin/actions'

type P = { id?: string; name?: string; description?: string; price?: string; imageUrl?: string | null; active?: boolean; variants?: string }

export default function ProductForm({ p = {} }: { p?: P }) {
  const [img, setImg] = useState(p.imageUrl ?? '')
  const [msg, setMsg] = useState('')

  async function upload(file?: File) {
    if (!file) return
    setMsg('Uploading…')
    const body = new FormData(); body.set('file', file)
    const res = await fetch('/api/upload', { method: 'POST', body })
    const data = await res.json()
    if (!res.ok) return setMsg(data.error)
    setImg(data.url); setMsg('Image uploaded')
  }

  return (
    <form action={saveProduct} className="form wide">
      <input type="hidden" name="id" defaultValue={p.id ?? ''} />
      <input type="hidden" name="imageUrl" value={img} />
      <label>Name<input name="name" defaultValue={p.name} required /></label>
      <label>Price<input name="price" type="number" step="0.01" min="0" defaultValue={p.price} required /></label>
      <label>Description<textarea name="description" rows={4} defaultValue={p.description} /></label>
      <label>Image
        <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => upload(e.target.files?.[0])} />
      </label>
      {img && <img src={img} alt="Preview" className="preview" />}
      {msg && <p role="status">{msg}</p>}
      <label>Sizes, colors and stock
        <textarea name="variants" rows={5} defaultValue={p.variants ?? 'S, Black, 10\nM, Black, 10\nL, Black, 10'} />
        <small>One per line: size, color, stock</small>
      </label>
      <label className="check"><input type="checkbox" name="active" defaultChecked={p.active ?? true} /> Visible in store</label>
      <button className="btn">Save product</button>
    </form>
  )
}
