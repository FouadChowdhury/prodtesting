'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useCart } from '@/lib/cart'

type V = { id: string; size: string; color: string; stock: number }
export default function AddToCart({ name, priceCents, imageUrl, variants }: { name: string; priceCents: number; imageUrl?: string | null; variants: V[] }) {
  const cart = useCart(); const router = useRouter()
  const [id, setId] = useState(variants.find((v) => v.stock > 0)?.id ?? '')
  const v = variants.find((x) => x.id === id)
  return (
    <div className="buy">
      <p className="label">Size</p>
      <div className="sizes" role="radiogroup" aria-label="Size">
        {variants.map((x) => (
          <button key={x.id} type="button" role="radio" aria-checked={x.id === id} disabled={x.stock === 0}
            className={x.id === id ? 'chip on' : 'chip'} onClick={() => setId(x.id)}>
            {x.size}{x.color !== 'Default' ? ` · ${x.color}` : ''}
          </button>
        ))}
      </div>
      <button className="btn" disabled={!v}
        onClick={() => { if (v) { cart.add({ variantId: v.id, name, size: v.size, color: v.color, priceCents, qty: 1, imageUrl }); router.push('/cart') } }}>
        {v ? 'Add to cart' : 'Sold out'}
      </button>
    </div>
  )
}
