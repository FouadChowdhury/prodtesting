'use client'
import { signOut } from 'next-auth/react'
export default function SignOutButton() {
  return <button className="link" onClick={() => signOut({ callbackUrl: '/admin/login' })}>Sign out</button>
}
