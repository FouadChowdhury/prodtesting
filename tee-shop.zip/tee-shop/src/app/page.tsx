import Link from 'next/link'
import { db } from '@/lib/db'
import { getContent } from '@/lib/content'
import { money } from '@/lib/format'

export const dynamic = 'force-dynamic'

export default async function Home() {
  const [c, products] = await Promise.all([
    getContent(),
    db.product.findMany({ where: { active: true }, orderBy: { createdAt: 'desc' } }),
  ])
  return (
    <>
      <section className="hero">
        <h1>{c.heroTitle}</h1>
        <p>{c.heroSubtitle}</p>
      </section>
      <section className="grid" aria-label="Products">
        {products.length === 0 && <p>No products yet — add the first one in the admin panel.</p>}
        {products.map((p, i) => (
          <Link key={p.id} href={`/products/${p.slug}`} className="card">
            <div className={`swatch s${i % 4}`}>{p.imageUrl && <img src={p.imageUrl} alt={p.name} />}</div>
            <h2>{p.name}</h2>
            <span>{money(p.priceCents)}</span>
          </Link>
        ))}
      </section>
    </>
  )
}
