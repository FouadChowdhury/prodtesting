import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { money } from '@/lib/format'
import AddToCart from '@/components/AddToCart'

export const dynamic = 'force-dynamic'

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const p = await db.product.findUnique({ where: { slug: params.slug }, include: { variants: { orderBy: { size: 'asc' } } } })
  if (!p || !p.active) notFound()
  return (
    <article className="detail">
      <div className="swatch s0 big">{p.imageUrl && <img src={p.imageUrl} alt={p.name} />}</div>
      <div>
        <h1>{p.name}</h1>
        <p className="price">{money(p.priceCents)}</p>
        <p className="desc">{p.description}</p>
        <AddToCart name={p.name} priceCents={p.priceCents} imageUrl={p.imageUrl} variants={p.variants} />
      </div>
    </article>
  )
}
