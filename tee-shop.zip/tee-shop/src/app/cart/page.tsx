'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useCart } from '@/lib/cart'
import { money } from '@/lib/format'

export default function CartPage() {
  const cart = useCart()
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)
  const [done, setDone] = useState<number | null>(null)

  async function place(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError('')
    const f = Object.fromEntries(new FormData(e.currentTarget)) as Record<string, string>
    const res = await fetch('/api/orders', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...f, items: cart.items.map((i) => ({ variantId: i.variantId, qty: i.qty })) }),
    })
    const data = await res.json(); setBusy(false)
    if (!res.ok) return setError(data.error)
    cart.clear(); setDone(data.number)
  }

  if (done) return <section className="narrow"><h1>Order #{done} received</h1><p>We'll email you when it ships. Pay on delivery.</p><Link href="/" className="btn">Keep shopping</Link></section>
  if (cart.items.length === 0) return <section className="narrow"><h1>Your cart is empty</h1><Link href="/" className="btn">Browse t-shirts</Link></section>

  return (
    <section className="checkout">
      <div>
        <h1>Your cart</h1>
        {cart.items.map((i) => (
          <div key={i.variantId} className="line">
            <div><strong>{i.name}</strong><br />{i.size} · {i.color}</div>
            <input type="number" min={0} max={20} value={i.qty} aria-label="Quantity" onChange={(e) => cart.setQty(i.variantId, +e.target.value)} />
            <span>{money(i.priceCents * i.qty)}</span>
          </div>
        ))}
        <p className="total">Total <strong>{money(cart.total)}</strong></p>
      </div>
      <form onSubmit={place} className="form">
        <h2>Delivery details</h2>
        <label>Full name<input name="name" required /></label>
        <label>Email<input name="email" type="email" required /></label>
        <label>Phone<input name="phone" required /></label>
        <label>Address<input name="address" required /></label>
        <label>City<input name="city" required /></label>
        <label>Order notes<textarea name="notes" rows={2} /></label>
        {error && <p role="alert" className="err">{error}</p>}
        {/* PAYMENT HOOK: swap this button for your gateway's checkout (Stripe, SSLCommerz, bKash, PayPal...)
            and mark orders PAID from the gateway's webhook. Default below = pay on delivery. */}
        <button className="btn" disabled={busy}>{busy ? 'Placing order…' : 'Place order (pay on delivery)'}</button>
      </form>
    </section>
  )
}
