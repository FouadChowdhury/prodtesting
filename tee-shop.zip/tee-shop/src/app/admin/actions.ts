'use server'
import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import bcrypt from 'bcryptjs'
import { db } from '@/lib/db'
import { requirePerm } from '@/lib/permissions'
import { slugify } from '@/lib/format'
import { CONTENT_DEFAULTS, type ContentKey } from '@/lib/content'

const str = (f: FormData, k: string) => String(f.get(k) ?? '').trim()

// ---------- Products ----------
export async function saveProduct(f: FormData) {
  await requirePerm('products')
  const id = str(f, 'id')
  const name = str(f, 'name')
  const priceCents = Math.round(parseFloat(str(f, 'price')) * 100)
  if (!name || !Number.isFinite(priceCents) || priceCents < 0) throw new Error('Name and a valid price are required.')

  // Variants textarea: one per line → "Size, Color, Stock"
  const variants = str(f, 'variants').split('\n').map((l) => l.split(',').map((x) => x.trim())).filter((p) => p[0])
    .map(([size, color = 'Default', stock = '0']) => ({ size, color, stock: Math.max(0, parseInt(stock) || 0) }))

  const data = {
    name, description: str(f, 'description'), priceCents,
    imageUrl: str(f, 'imageUrl') || null, active: f.get('active') === 'on',
  }
  await db.$transaction(async (tx) => {
    const product = id
      ? await tx.product.update({ where: { id }, data })
      : await tx.product.create({ data: { ...data, slug: `${slugify(name)}-${Date.now().toString(36)}` } })
    await tx.variant.deleteMany({ where: { productId: product.id } })
    await tx.variant.createMany({ data: variants.map((v) => ({ ...v, productId: product.id })) })
  })
  revalidatePath('/'); revalidatePath('/admin/products')
  redirect('/admin/products')
}

// ---------- Orders ----------
export async function updateOrderStatus(f: FormData) {
  await requirePerm('orders')
  const id = str(f, 'id'); const status = str(f, 'status') as any
  const order = await db.order.findUnique({ where: { id }, include: { items: true } })
  if (!order) return
  await db.$transaction(async (tx) => {
    // Cancelling puts the stock back
    if (status === 'CANCELLED' && order.status !== 'CANCELLED') {
      for (const i of order.items) if (i.variantId)
        await tx.variant.updateMany({ where: { id: i.variantId }, data: { stock: { increment: i.qty } } })
    }
    await tx.order.update({ where: { id }, data: { status } })
  })
  revalidatePath('/admin/orders')
}

// ---------- Storefront content ----------
export async function saveContent(f: FormData) {
  await requirePerm('content')
  for (const key of Object.keys(CONTENT_DEFAULTS) as ContentKey[]) {
    const value = str(f, key)
    await db.siteContent.upsert({ where: { key }, update: { value }, create: { key, value } })
  }
  revalidatePath('/'); revalidatePath('/admin/content')
}

// ---------- Staff accounts (Owner only) ----------
export async function createStaff(f: FormData) {
  await requirePerm('users')
  const password = str(f, 'password')
  if (password.length < 10) throw new Error('Password must be at least 10 characters.')
  await db.user.create({
    data: { name: str(f, 'name'), email: str(f, 'email').toLowerCase(), role: str(f, 'role') as any, passwordHash: await bcrypt.hash(password, 12) },
  })
  revalidatePath('/admin/users')
}

export async function toggleStaff(f: FormData) {
  const me = await requirePerm('users')
  const id = str(f, 'id')
  if (id === me.id) return // can't lock yourself out
  const u = await db.user.findUnique({ where: { id } })
  if (u) await db.user.update({ where: { id }, data: { active: !u.active } })
  revalidatePath('/admin/users')
}
