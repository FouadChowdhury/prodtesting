import { db } from '@/lib/db'
import { requirePerm } from '@/lib/permissions'
import { createStaff, toggleStaff } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function Users() {
  await requirePerm('users')
  const users = await db.user.findMany({ orderBy: { createdAt: 'asc' } })
  return (
    <>
      <h1>Staff</h1>
      <table>
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th></th></tr></thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.name}</td><td>{u.email}</td><td>{u.role.toLowerCase()}</td>
              <td><form action={toggleStaff}><input type="hidden" name="id" value={u.id} />
                <button className="link">{u.active ? 'Deactivate' : 'Reactivate'}</button></form></td>
            </tr>
          ))}
        </tbody>
      </table>
      <h2>Add a team member</h2>
      <form action={createStaff} className="form wide">
        <label>Name<input name="name" required /></label>
        <label>Email<input name="email" type="email" required /></label>
        <label>Temporary password<input name="password" type="password" minLength={10} required /></label>
        <label>Role
          <select name="role" defaultValue="EDITOR">
            <option value="EDITOR">Editor — storefront text only</option>
            <option value="SUPPORT">Support — orders only</option>
            <option value="MANAGER">Manager — products, orders, text</option>
            <option value="OWNER">Owner — everything, including staff</option>
          </select>
        </label>
        <button className="btn">Create account</button>
      </form>
    </>
  )
}
