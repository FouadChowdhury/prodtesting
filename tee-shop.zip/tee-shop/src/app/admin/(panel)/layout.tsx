import Link from 'next/link'
import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from '@/lib/auth'
import { can } from '@/lib/permissions'
import SignOutButton from '@/components/SignOutButton'

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  const s = await getServerSession(authOptions)
  if (!s?.user) redirect('/admin/login')
  const r = s.user.role
  return (
    <div className="admin">
      <nav className="side">
        <strong>Admin</strong>
        <Link href="/admin">Dashboard</Link>
        {can(r, 'products') && <Link href="/admin/products">Products</Link>}
        {can(r, 'orders') && <Link href="/admin/orders">Orders</Link>}
        {can(r, 'content') && <Link href="/admin/content">Storefront text</Link>}
        {can(r, 'users') && <Link href="/admin/users">Staff</Link>}
        <span className="who">{s.user.name} ({r.toLowerCase()})</span>
        <SignOutButton />
      </nav>
      <section className="panel">{children}</section>
    </div>
  )
}
