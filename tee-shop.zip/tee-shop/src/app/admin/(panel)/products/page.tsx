import Link from 'next/link'
import { db } from '@/lib/db'
import { requirePerm } from '@/lib/permissions'
import { money } from '@/lib/format'

export const dynamic = 'force-dynamic'

export default async function Products() {
  await requirePerm('products')
  const products = await db.product.findMany({ include: { variants: true }, orderBy: { createdAt: 'desc' } })
  return (
    <>
      <div className="row"><h1>Products</h1><Link href="/admin/products/new" className="btn">Add product</Link></div>
      <table>
        <thead><tr><th>Name</th><th>Price</th><th>In stock</th><th>Status</th><th></th></tr></thead>
        <tbody>
          {products.map((p) => (
            <tr key={p.id}>
              <td>{p.name}</td><td>{money(p.priceCents)}</td>
              <td>{p.variants.reduce((n, v) => n + v.stock, 0)}</td>
              <td>{p.active ? 'Visible' : 'Hidden'}</td>
              <td><Link href={`/admin/products/${p.id}`}>Edit</Link></td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}
