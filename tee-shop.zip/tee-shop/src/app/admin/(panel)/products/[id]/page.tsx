import { notFound } from 'next/navigation'
import { db } from '@/lib/db'
import { requirePerm } from '@/lib/permissions'
import ProductForm from '@/components/ProductForm'

export default async function EditProduct({ params }: { params: { id: string } }) {
  await requirePerm('products')
  if (params.id === 'new') return <><h1>Add product</h1><ProductForm /></>
  const p = await db.product.findUnique({ where: { id: params.id }, include: { variants: true } })
  if (!p) notFound()
  return (
    <>
      <h1>Edit product</h1>
      <ProductForm p={{
        id: p.id, name: p.name, description: p.description, price: (p.priceCents / 100).toFixed(2),
        imageUrl: p.imageUrl, active: p.active,
        variants: p.variants.map((v) => `${v.size}, ${v.color}, ${v.stock}`).join('\n'),
      }} />
    </>
  )
}
