import { db } from '@/lib/db'
import { can } from '@/lib/permissions'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { money } from '@/lib/format'

export const dynamic = 'force-dynamic'

export default async function Dashboard() {
  const role = (await getServerSession(authOptions))!.user.role
  if (!can(role, 'orders')) return <><h1>Welcome</h1><p>Use “Storefront text” to update the homepage wording.</p></>
  const [pending, today, lowStock] = await Promise.all([
    db.order.count({ where: { status: 'PENDING' } }),
    db.order.aggregate({ _sum: { totalCents: true }, _count: true, where: { createdAt: { gte: new Date(new Date().setHours(0, 0, 0, 0)) } } }),
    db.variant.count({ where: { stock: { lte: 3 }, product: { active: true } } }),
  ])
  return (
    <>
      <h1>Dashboard</h1>
      <div className="stats">
        <div><b>{pending}</b>orders waiting</div>
        <div><b>{today._count}</b>orders today</div>
        <div><b>{money(today._sum.totalCents ?? 0)}</b>sales today</div>
        <div><b>{lowStock}</b>sizes low on stock</div>
      </div>
    </>
  )
}
