import { requirePerm } from '@/lib/permissions'
import { getContent } from '@/lib/content'
import { saveContent } from '../../actions'

export const dynamic = 'force-dynamic'

export default async function ContentPage() {
  await requirePerm('content')
  const c = await getContent()
  return (
    <>
      <h1>Storefront text</h1>
      <form action={saveContent} className="form wide">
        <label>Announcement bar<input name="announcement" defaultValue={c.announcement} /></label>
        <label>Homepage headline<input name="heroTitle" defaultValue={c.heroTitle} /></label>
        <label>Homepage subtitle<textarea name="heroSubtitle" rows={2} defaultValue={c.heroSubtitle} /></label>
        <button className="btn">Publish changes</button>
      </form>
    </>
  )
}
