import { db } from '@/lib/db'
import { requirePerm } from '@/lib/permissions'
import { money } from '@/lib/format'
import { updateOrderStatus } from '../../actions'

export const dynamic = 'force-dynamic'
const STATUSES = ['PENDING', 'PAID', 'PROCESSING', 'SHIPPED', 'DELIVERED', 'CANCELLED']

export default async function Orders() {
  await requirePerm('orders')
  const orders = await db.order.findMany({ include: { items: true }, orderBy: { createdAt: 'desc' }, take: 100 })
  return (
    <>
      <h1>Orders</h1>
      {orders.length === 0 && <p>No orders yet. They'll show up here as soon as a customer checks out.</p>}
      {orders.map((o) => (
        <details key={o.id} className="order">
          <summary>
            <b>#{o.number}</b> {o.name} — {money(o.totalCents)} — {o.createdAt.toLocaleDateString()} — <em>{o.status.toLowerCase()}</em>
          </summary>
          <p>{o.email} · {o.phone}<br />{o.address}, {o.city}{o.notes && <><br />Note: {o.notes}</>}</p>
          <ul>{o.items.map((i) => <li key={i.id}>{i.qty} × {i.productName} ({i.size}, {i.color})</li>)}</ul>
          <form action={updateOrderStatus} className="row">
            <input type="hidden" name="id" value={o.id} />
            <select name="status" defaultValue={o.status}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
            <button className="btn small">Update status</button>
          </form>
        </details>
      ))}
    </>
  )
}
