'use client'
import { useState } from 'react'
import { signIn } from 'next-auth/react'

export default function Login() {
  const [error, setError] = useState('')
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const f = new FormData(e.currentTarget)
    const res = await signIn('credentials', { email: f.get('email'), password: f.get('password'), redirect: false })
    if (res?.ok) window.location.href = '/admin'
    else setError('Email or password is incorrect.')
  }
  return (
    <section className="narrow">
      <h1>Staff sign in</h1>
      <form onSubmit={submit} className="form">
        <label>Email<input name="email" type="email" required autoComplete="username" /></label>
        <label>Password<input name="password" type="password" required autoComplete="current-password" /></label>
        {error && <p role="alert" className="err">{error}</p>}
        <button className="btn">Sign in</button>
      </form>
    </section>
  )
}
