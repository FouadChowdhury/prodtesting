import type { Metadata } from 'next'
import { Bricolage_Grotesque, Work_Sans } from 'next/font/google'
import Link from 'next/link'
import { getContent } from '@/lib/content'
import CartLink from '@/components/CartLink'
import './globals.css'

const display = Bricolage_Grotesque({ subsets: ['latin'], variable: '--font-display' })
const body = Work_Sans({ subsets: ['latin'], variable: '--font-body' })

export const metadata: Metadata = { title: 'Tee Shop', description: 'Heavyweight t-shirts, small print runs.' }

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const c = await getContent()
  return (
    <html lang="en" className={`${display.variable} ${body.variable}`}>
      <body>
        <div className="announce">{c.announcement}</div>
        <header className="bar">
          <Link href="/" className="logo">tee shop</Link>
          <CartLink />
        </header>
        <main>{children}</main>
        <footer className="foot">© {new Date().getFullYear()} Tee Shop</footer>
      </body>
    </html>
  )
}
