import { NextResponse } from 'next/server'
import { z } from 'zod'
import { db } from '@/lib/db'

const schema = z.object({
  name: z.string().min(2), email: z.string().email(), phone: z.string().min(6),
  address: z.string().min(5), city: z.string().min(2), notes: z.string().max(500).optional(),
  items: z.array(z.object({ variantId: z.string(), qty: z.number().int().min(1).max(20) })).min(1),
})

export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json().catch(() => null))
  if (!parsed.success) return NextResponse.json({ error: 'Please check your details and try again.' }, { status: 400 })
  const d = parsed.data
  try {
    // Prices and stock come from the database, never from the browser.
    const order = await db.$transaction(async (tx) => {
      let total = 0
      const lines: { variantId: string; productName: string; size: string; color: string; unitCents: number; qty: number }[] = []
      for (const it of d.items) {
        const v = await tx.variant.findUnique({ where: { id: it.variantId }, include: { product: true } })
        if (!v || !v.product.active) throw new Error('An item in your cart is no longer available.')
        if (v.stock < it.qty) throw new Error(`Only ${v.stock} left of ${v.product.name} (${v.size}).`)
        await tx.variant.update({ where: { id: v.id }, data: { stock: { decrement: it.qty } } })
        total += v.product.priceCents * it.qty
        lines.push({ variantId: v.id, productName: v.product.name, size: v.size, color: v.color, unitCents: v.product.priceCents, qty: it.qty })
      }
      const { items: _omit, ...customer } = d
      return tx.order.create({ data: { ...customer, totalCents: total, items: { create: lines } } })
    })
    return NextResponse.json({ number: order.number })
  } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : 'Could not place order.' }, { status: 409 })
  }
}
