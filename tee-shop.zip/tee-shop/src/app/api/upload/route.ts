import { NextResponse } from 'next/server'
import { writeFile } from 'fs/promises'
import path from 'path'
import { randomUUID } from 'crypto'
import { requirePerm } from '@/lib/permissions'

const TYPES: Record<string, string> = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp' }

// DEV STORAGE: writes to /public/uploads. On Vercel/serverless there is no persistent disk —
// swap the writeFile call for an upload to Cloudinary, S3 or Vercel Blob and return that URL.
export async function POST(req: Request) {
  await requirePerm('products')
  const file = (await req.formData()).get('file')
  if (!(file instanceof File) || !TYPES[file.type]) return NextResponse.json({ error: 'Use a JPG, PNG or WebP image.' }, { status: 400 })
  if (file.size > 5 * 1024 * 1024) return NextResponse.json({ error: 'Image must be under 5 MB.' }, { status: 400 })
  const name = `${randomUUID()}.${TYPES[file.type]}`
  await writeFile(path.join(process.cwd(), 'public', 'uploads', name), Buffer.from(await file.arrayBuffer()))
  return NextResponse.json({ url: `/uploads/${name}` })
}
