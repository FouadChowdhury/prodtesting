export { default } from 'next-auth/middleware'
// First line of defence: any /admin page except /admin/login needs a session.
// Per-role checks happen again on the server in requirePerm().
export const config = { matcher: ['/admin', '/admin/((?!login).+)'] }
