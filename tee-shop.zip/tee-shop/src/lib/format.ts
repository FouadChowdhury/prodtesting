export const money = (cents: number) =>
  new Intl.NumberFormat('en-US', { style: 'currency', currency: process.env.NEXT_PUBLIC_CURRENCY || 'USD' }).format(cents / 100)

export const slugify = (s: string) =>
  s.toLowerCase().trim().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')
