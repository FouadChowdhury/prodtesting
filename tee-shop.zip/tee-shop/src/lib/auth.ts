import type { NextAuthOptions } from 'next-auth'
import Credentials from 'next-auth/providers/credentials'
import bcrypt from 'bcryptjs'
import { db } from './db'

export const authOptions: NextAuthOptions = {
  session: { strategy: 'jwt', maxAge: 8 * 60 * 60 }, // staff sessions last one work day
  pages: { signIn: '/admin/login' },
  providers: [
    Credentials({
      credentials: { email: {}, password: {} },
      async authorize(c) {
        if (!c?.email || !c.password) return null
        const u = await db.user.findUnique({ where: { email: c.email.toLowerCase() } })
        if (!u || !u.active) return null
        if (!(await bcrypt.compare(c.password, u.passwordHash))) return null
        return { id: u.id, name: u.name, email: u.email, role: u.role } as any
      },
    }),
  ],
  callbacks: {
    jwt({ token, user }) {
      if (user) { token.role = (user as any).role; token.uid = user.id }
      return token
    },
    session({ session, token }) {
      session.user.role = token.role
      session.user.id = token.uid
      return session
    },
  },
}
