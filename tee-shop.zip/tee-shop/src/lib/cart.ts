'use client'
import { useEffect, useState } from 'react'

export type CartItem = {
  variantId: string; name: string; size: string; color: string
  priceCents: number; qty: number; imageUrl?: string | null
}
const KEY = 'tee-cart'
const read = (): CartItem[] => {
  try { return JSON.parse(localStorage.getItem(KEY) || '[]') } catch { return [] }
}

export function useCart() {
  const [items, setItems] = useState<CartItem[]>([])
  useEffect(() => {
    const sync = () => setItems(read())
    sync()
    window.addEventListener('cart-change', sync)
    return () => window.removeEventListener('cart-change', sync)
  }, [])
  const write = (next: CartItem[]) => {
    localStorage.setItem(KEY, JSON.stringify(next))
    window.dispatchEvent(new Event('cart-change'))
  }
  return {
    items,
    count: items.reduce((n, i) => n + i.qty, 0),
    total: items.reduce((n, i) => n + i.qty * i.priceCents, 0),
    add(item: CartItem) {
      const cur = read(); const hit = cur.find((i) => i.variantId === item.variantId)
      hit ? (hit.qty += item.qty) : cur.push(item); write(cur)
    },
    setQty(variantId: string, qty: number) {
      write(read().map((i) => (i.variantId === variantId ? { ...i, qty } : i)).filter((i) => i.qty > 0))
    },
    clear: () => write([]),
  }
}
