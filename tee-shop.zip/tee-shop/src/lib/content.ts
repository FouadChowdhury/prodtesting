import { db } from './db'

export const CONTENT_DEFAULTS = {
  announcement: 'Free shipping on orders over $60',
  heroTitle: 'Shirts worth wearing twice a week.',
  heroSubtitle: 'Heavyweight cotton, small print runs, designed in-house.',
}
export type ContentKey = keyof typeof CONTENT_DEFAULTS

export async function getContent() {
  const rows = await db.siteContent.findMany()
  return { ...CONTENT_DEFAULTS, ...Object.fromEntries(rows.map((r) => [r.key, r.value])) } as typeof CONTENT_DEFAULTS
}
