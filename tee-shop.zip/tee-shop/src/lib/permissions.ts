import { getServerSession } from 'next-auth'
import { redirect } from 'next/navigation'
import { authOptions } from './auth'

export type Perm = 'products' | 'orders' | 'content' | 'users'
type Role = 'OWNER' | 'MANAGER' | 'EDITOR' | 'SUPPORT'

// One place that defines who can do what.
export const PERMS: Record<Role, Perm[]> = {
  OWNER:   ['products', 'orders', 'content', 'users'],
  MANAGER: ['products', 'orders', 'content'],
  EDITOR:  ['content'],   // can safely edit storefront text, nothing else
  SUPPORT: ['orders'],
}

export const can = (role: Role, p: Perm) => PERMS[role].includes(p)

/** Call at the top of every admin page, server action and API route. */
export async function requirePerm(p: Perm) {
  const s = await getServerSession(authOptions)
  if (!s?.user || !can(s.user.role, p)) redirect('/admin/login')
  return s.user
}
